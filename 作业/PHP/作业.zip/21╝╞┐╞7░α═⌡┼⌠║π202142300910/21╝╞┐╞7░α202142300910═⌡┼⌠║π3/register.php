<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>注册</title>
</head>

<body>
<?php
$useName=$_POST["useName"];
$password=$_POST["password"];
$password1=$_POST["password1"];
echo "用户名：".$useName;
echo "<br/>";
echo "密码：".$password;
echo "<br/>";
echo "确认密码：".$password1;
echo "<br/>";
if($password==$password1){
	echo "你输入的两次密码一致，请你进行注册";
	}else{
	echo "你输入的两次密码不一致，请你重新输入密码";?>
	请你点击<a href="login.php">这里</a>重新输入
	
	<?php } ?>
?>
</body>
</html>
