/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 50726
Source Host           : localhost:3306
Source Database       : student

Target Server Type    : MYSQL
Target Server Version : 50726
File Encoding         : 65001

Date: 2023-10-08 16:40:24
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stuNo` char(13) NOT NULL,
  `stuName` varchar(50) NOT NULL,
  `sex` enum('男','女') NOT NULL DEFAULT '男',
  `birthday` date DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  PRIMARY KEY (`stuNo`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('1', '2022001', '李四', '女', '2000-12-09', '23');
INSERT INTO `student` VALUES ('2', '2022002', '王五', '男', '2002-12-09', '21');
INSERT INTO `student` VALUES ('4', '2022004', '吴明', '男', '2001-12-09', '22');
INSERT INTO `student` VALUES ('5', '2022005', '赵庆', '女', '2000-12-09', '23');
INSERT INTO `student` VALUES ('6', '2022006', '杜江', '女', '2002-12-09', '21');
