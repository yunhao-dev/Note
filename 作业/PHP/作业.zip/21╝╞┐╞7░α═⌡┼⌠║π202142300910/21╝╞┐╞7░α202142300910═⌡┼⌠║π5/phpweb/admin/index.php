<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body>
<table width="732" height="354" border="1" align="center">
  <tr>
    <td width="200"><img src="images/log.bmp" / width="200" height="70"></td>
    <td colspan="2" align="center" bgcolor="#CCFF00"><h1>学生管理系统</h1></td>
  </tr>
  <tr>
    <td rowspan="2"><p>注意事项：</p>
    <p>1、管理员具备数据库的浏览、增删改权限，数据一但删除或更新不能恢复，请慎重操作！</p>
    <p>2、如有技术问题，请联系技术人 员：12345678901 </p>
    <p>&nbsp;</p></td>
    <td width="294" height="65" align="center"><h3><a href="student.php">学生表</a></h3></td>
    <td width="216">&nbsp;</td>
  </tr>
  <tr>
    <td height="68" align="center"><h3>课程表</h3></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="97">功能说明</td>
    <td align="center"><h3>成绩表</h3></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3" align="center">地址：郑州市二七区马寨工业园学院路1号
      <br/>邮编：450064
    网址：<a href="http://www.zit.edu.cn/">http://www.zit.edu.cn</a></td>
  </tr>
</table>
</body>
</html>