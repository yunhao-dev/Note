﻿<title> 追加学生记录成功</title>
<?php
include_once "conn.php";
$stuNo=$_POST['stuNo'];
$stuName=$_POST['stuName'];
$sex=$_POST['sex'];
$birthday=$_POST['birthday'];
$sql="insert into student values('$stuNo','$stuName','$sex','$birthday')";
mysqli_query($conn,$sql);
header("Location:student.php");
?>