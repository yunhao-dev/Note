<?php
$conn=mysqli_connect("localhost","root","root","student");
if(mysqli_connect_errno($conn)){
	echo "mysql连接出错".mysqli_connect_error();
	}
mysqli_query($conn,"set names utf-8");
?>