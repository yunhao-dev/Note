<?php
include_once "conn.php";
$stuNo=$_POST["stuNo"];
$stuName=$_POST["stuName"];
$sex=$_POST["sex"];
$birthday=$_POST["birthday"];
$sql="update student set stuName='$stuName',sex='$sex',birthday='$birthday' where stuNo='$stuNo'";
mysqli_query($conn,$sql);
//ת��ѧ�����鿴����Ч��
header("Location:student.php");
?>