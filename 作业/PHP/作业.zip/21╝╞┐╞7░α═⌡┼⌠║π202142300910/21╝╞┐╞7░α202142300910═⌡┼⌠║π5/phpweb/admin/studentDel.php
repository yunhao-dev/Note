﻿<?php
include_once "conn.php";
$id=$_GET["id"];
$sql="delete from student where stuNo='$id'";
//='{$_GET["No"]}'
mysqli_query($conn,$sql);
?><title>删除学生记录</title>
请单击<a href="student.php">这里</a>，转向学生表查看删除情况
