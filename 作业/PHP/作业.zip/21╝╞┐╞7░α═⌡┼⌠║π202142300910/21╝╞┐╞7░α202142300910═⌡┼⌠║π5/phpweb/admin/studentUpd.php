﻿<?php
include_once "conn.php";
$id2=$_GET["id2"];
$sql="select * from student where stuNo='$id2'";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($result);
?>
<form name="form1" method="post" action="studentUpdok.php">
  <table width="400" border="1">
    <tr>
      <td colspan="2">更新学生记录</td>
    </tr>
    <tr>
      <td>学号</td>
      <td><label>
        <input name="stuNo" type="text" id="stuNo" size="20" readonly="1" value="<?php echo $row["stuNo"];?>">
      </label></td>
    </tr>
    <tr>
      <td>姓名</td>
      <td><input name="stuName" type="text" id="stuName" size="20" value="<?php echo $row["stuName"];?>"></td>
    </tr>
    <tr>
      <td>性别</td>
      <td><input name="sex" type="text" id="sex" size="20" value="<?php echo $row['sex'];?>"></td>
    </tr>
    <tr>
      <td>出生日期</td>
      <td><input name="birthday" type="text" id="birthday" size="20" value="<?php echo $row['birthday'];?>"></td>
    </tr>
    <tr>
      <td colspan="2"><label>
        <input type="submit" name="Submit" value="提交">
        <input type="reset" name="Submit2" value="重置">
      </label></td>
    </tr>
  </table>
</form>
