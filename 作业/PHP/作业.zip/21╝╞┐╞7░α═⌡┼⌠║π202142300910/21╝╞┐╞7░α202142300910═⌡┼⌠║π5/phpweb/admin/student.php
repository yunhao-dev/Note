﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>数据库访问</title>
</head>

<body>
<?php
include_once "conn.php";
$sql="select * from student";
$result=mysqli_query($conn,$sql);

echo '<table border="1" align="center">';
echo '<tr><td colspan="6" align="center" bgcolor="yellow"><h1>学生信息表</h1></td></tr>';
echo '<tr height="50">';
echo "<td>序号</td>";
echo "<td>学号</td>";
echo "<td>姓名</td>";
echo "<td>性别</td>";
echo "<td>出生日期</td>";
echo "<td>操作</td>";
echo"</tr>";
while($row=mysqli_fetch_array($result)){?>
    <tr>
    <td width="100" height="50"><?php echo $row['id'];?></td>
    <td width="100"><?php echo $row['stuNo'];?></td>
    <td width="100"><?php echo $row['stuName'];?></td>
    <td width="100"><?php echo $row['sex'];?></td>
    <td width="100"><?php echo $row['birthday'];?></td>
    <td><a href="studentUpd.php?id2=<?php echo $row['stuNo'];?>">更新</a> <a href="studentDel.php?id=<?php echo $row['stuNo'];?>">删除</a></td>
    </tr>	
	<?php }?>
</table>
<a href="studentAdd.php">追加记录</a>
<?php 
// 释放结果集
mysqli_free_result($result);
// 关闭连接
mysqli_close($conn);
?>
</body>
</html>