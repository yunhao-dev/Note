<?php
$admin=$_POST['admin'];
$password=$_POST['password'];
if($admin=="admin"&&$password=="123456"){
	header("location:index.php");
}else{
	echo "您输入的用户名或密码不正确，请重新输入!";
	header("location:login.php");
}
?>