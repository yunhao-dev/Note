/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 50726
Source Host           : localhost:3306
Source Database       : course

Target Server Type    : MYSQL
Target Server Version : 50726
File Encoding         : 65001

Date: 2023-09-22 17:07:04
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for course
-- ----------------------------
DROP TABLE IF EXISTS `course`;
CREATE TABLE `course` (
  `课程号` char(4) COLLATE utf8_unicode_ci NOT NULL,
  `课程名` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `开课学期` enum('','5','4','3','2','1') COLLATE utf8_unicode_ci NOT NULL,
  `学时` int(11) NOT NULL,
  `学分` float DEFAULT NULL,
  PRIMARY KEY (`课程号`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of course
-- ----------------------------
INSERT INTO `course` VALUES ('114', '计算机数学', '1', '56', '3.5');
INSERT INTO `course` VALUES ('102', 'C语言程序设计', '1', '72', '4.5');
INSERT INTO `course` VALUES ('209', 'JAVA程序设计基础', '3', '64', '4');
INSERT INTO `course` VALUES ('104', 'SQL数据库技术', '3', '64', '4');
INSERT INTO `course` VALUES ('101', '网络编程PHP', '4', '96', '6');
INSERT INTO `course` VALUES ('109', 'JSP程序设计', '4', '64', '4');
INSERT INTO `course` VALUES ('103', '网页设计与制作', '3', '64', '4');
INSERT INTO `course` VALUES ('210', '数据结构', '2', '64', '4');
INSERT INTO `course` VALUES ('205', '软件测试技术', '5', '64', '4');
